Dhruvil Patel portfolio — static site (no build step).
Files: index.html, Dhruvil_Patel_Resume.pdf
Edit the CONFIG / SKILLS / PROJECTS / CERTS blocks near the top of the <script> in index.html to add links, skills and projects.
Vercel settings: Framework Preset = Other, no build command, no output directory.
